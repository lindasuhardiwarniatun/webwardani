<!DOCTYPE html> 

    <head>
        <title>Beranda</title> 
        <style>
            body {
            margin: 0;
            padding: 0;
            background: url(img/beranda.png);
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            background-attachment: fixed;
            font-family: sans-serif;
        }
            

            .Logo1{
                padding: 15px;
                margin-left: 150px;
                position: relative;
            }

            .JudulHeader{
                color: white;
                font-family: Arial, Helvetica, sans-serif;
                position: absolute;
                margin-top: 40px;
                margin-left: 30px;
                font-size: 30px;
                
                
            }

            .NavMenu ul{
                list-style-type: none;
                margin-left: 70%;
                cursor: pointer;
                float: left;
                font-weight: 400;
                
            }
            .NavMenu ul li{
                list-style-type: none;
                display: inline-block;
                padding: 35px 15px;

            }
            .NavMenu ul li a{
                color: white;
                text-decoration: none;
            }

            .NavMenu ul li :hover{
                border-bottom: 3px solid #F0A04B;
                transition: all .3s ease ;
                
                
            }
            .header{
                text-align: center;
                position: absolute;
                top: 40%;
                left: 45%;
                transform: translate(-45%, -50%);
            }
            .header h1{
                color: #F0A04B;
                text-align: left;
                font-size: 50px;
            }
            .contentheader{
                text-align: center;
                position: absolute;
                top: 47%;
                left: 45%;
                transform: translate(-45%, -50%);
                color: white;
            }
        
        </style>

    </head>
    
    <body>
    
    <div class="Header">
    <div class="JudulHeader"><b>Website al-Khair</b></div>

    </div>

    <div class="NavMenu">
    
        
        <ul>
        
            <li><a href="beranda.php" >Home</a></li>
            <li><a href="registrasi.php">Daftar</a></li>
            <li><a href="login.php">Masuk</a></li>
        </ul>
        
    </div>
    </div>
    <div class="header">
        <h1>Selamat Datang</h1>

    </div>
    <div class="contentheader">
        <p>Santri/Santriwati SMK Tahfidz Al-Khair NWDI Sambelia</p>

    </div>
    </body>

</html>