<?php 

$conn = mysqli_connect("localhost", "root", "", "uas4b");


function query($query) {
    global $conn;
    $result = mysqli_query($conn, $query);
    $rows = [];
    while( $row = mysqli_fetch_assoc($result)) {
        $rows[] = $row;
    }

    return $rows;
}

function tambah($data) {
    global $conn;


    $nama = htmlspecialchars($data["nama"]);
    $nis = htmlspecialchars($data["nis"]);
    $alamat = htmlspecialchars($data["alamat"]);
    $jurusan = htmlspecialchars($data["jurusan"]);

    $gambar = upload();
    if( !$gambar ) {
        return false;
    }

    $query = "INSERT INTO santri
                VALUES
                ('', '$nama', '$nis', '$alamat', '$jurusan', '$gambar')
    
            ";
    mysqli_query($conn, $query);


    return mysqli_affected_rows($conn);
}

function upload() {
    $namaFile = $_FILES['gambar']['name'];
    $ukuranFile = $_FILES['gambar']['size'];
    $error = $_FILES['gambar']['error'];
    $tmpName =$_FILES['gambar']['tmp_name'];

    if( $error === 4 ) {
        echo "<script>
                alert('pilih gambar terlebih dahulu');
        
             </script>";
        return false;
    }

    $ekstensiGambarValid = ['jpg', 'jpeg', 'png', 'JPG', 'JPEG', 'PNG'];
    $ekstensiGambar = explode('.', $namaFile);
    $ekstensiGambar = end($ekstensiGambar);

    if(!in_array($ekstensiGambar, $ekstensiGambarValid)){
        echo "<script>
                alert('file yang anda uploaad bukan gambar');
        
             </script>";
        return false;
    }

    if( $ukuranFile > 1000000 ) {
        echo "<script>
                alert('ukuran file yang anda upload terlalu besar');
        
             </script>";
        return false;
    }

    $namaFileBaru = uniqid();
    $namaFileBaru .= '.';
    $namaFileBaru .= $ekstensiGambar;

    move_uploaded_file($tmpName, 'img/' . $namaFileBaru);

    return $namaFileBaru;
}

function hapus($id) {
    global $conn;
    mysqli_query($conn, "DELETE FROM santri WHERE id = $id");

    return mysqli_affected_rows($conn);
}

function edit($data) {
    global $conn;

    $id = $data["id"];
    $nama = htmlspecialchars($data["nama"]);
    $nis = htmlspecialchars($data["nis"]);
    $alamat = htmlspecialchars($data["alamat"]);
    $jurusan = htmlspecialchars($data["jurusan"]);

    $gambarLama = htmlspecialchars($data["gambarLama"]);

    if( $_FILES['gambar']['error'] === 4) {
        $gambar = $gambarLama;
    }else {
        $gambar = upload();

    }

    

    $query = "UPDATE santri SET
                nama = '$nama',
                nis = '$nis',
                alamat = '$alamat',
                jurusan = '$jurusan',
                gambar = '$gambar'

            WHERE id = $id
    
            ";
    mysqli_query($conn, $query);


    return mysqli_affected_rows($conn);
}

function cari($keyword) {
    $query = "SELECT * FROM santri 
                WHERE 
                
                nama LIKE '%$keyword%' OR
                nis LIKE '%$keyword%' OR
                alamat LIKE '%$keyword%' OR
                jurusan LIKE '%$keyword%' 
    
            ";

    return query($query);
}

function registrasi($data){
    global $conn;

    $username = strtolower(stripslashes($data["username"]));
    $password = mysqli_real_escape_string($conn, $data["password"]);
    $password2 = mysqli_real_escape_string($conn, $data["password2"]);

    $result = mysqli_query($conn, "SELECT username FROM user WHERE username = '$username'");

     if( mysqli_fetch_assoc($result)) {
        echo "<script>
                alert('username sudah terdaftar!')
                </script>";

                return false;
     }

    if( $password !== $password2) {
        echo "<script>
                alert('konfirmasi password tidak sesuai');
            </script>";
        return false;
    }

    $password = password_hash($password, PASSWORD_DEFAULT);

    mysqli_query($conn, "INSERT INTO user VALUES('', '$username', '$password')");

    return mysqli_affected_rows($conn);


}

?>