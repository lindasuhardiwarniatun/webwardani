<?php 
session_start();

if( !isset($_SESSION["login"])) {
    header("location: beranda.php");
    exit;
}

require 'functions.php';

$jumlahDataPerHalaman = 4;
$jumlahSemuaData = count(query("SELECT * FROM santri"));
$jumlahHalaman = ceil($jumlahSemuaData / $jumlahDataPerHalaman);
$halamanAktif = ( isset($_GET["halaman"])) ? $_GET["halaman"] : 1;
$dataAwal = ( $jumlahDataPerHalaman * $halamanAktif ) - $jumlahDataPerHalaman;




$santri = query("SELECT *FROM santri LIMIT $dataAwal, $jumlahDataPerHalaman");

if( isset($_POST["cari"])) {
    $santri = cari($_POST["keyword"]);
}

?>


<!DOCTYPE html>
<html>
    <head>
        <title>Halaman Admin</title>
        <style>
            body{
                background-color: #E1EEDD;
            }

            table, tr, th, td{ 
                border: 1px solid black; 
                border-collapse: collapse; 
                padding: 5px; 
            } 
    
            table{ 
                width: 80%; 
            } 
    
            th{ 
                background-color:#F0A04B ; 
                color: #FEFBE9; 
            } 

            .Header{
                padding:20px;
                margin: 10px;
            }

            .JudulHeader{
                color: #F0A04B;
                font-family: Arial, Helvetica, sans-serif;
                position: absolute;
                margin-top: 40px;
                margin-left: 120px;
                font-size: 30px;
                
            }

            .NavMenu ul{
                list-style-type: none;
                margin-left: 70%;
                cursor: pointer;
                float: left;
                font-weight: 400;
                
            }

            .NavMenu ul li{
                list-style-type: none;
                display: inline-block;
                padding: 15px 15px;
            }
            .NavMenu ul li a{
                color: #183A1D;
                text-decoration: none;
            }

            .NavMenu ul li :hover{
                border-bottom: 3px solid #F0A04B;
                transition: all .3s ease ;
                
            }
            form{
                padding: 55px 0px;
                margin-left: 66%;
                margin-top: 10px;
            }
            table{
                color: #183A1D;
                
                margin-top: -70px;
            }
            .button2 {border-radius: 4px;}
            
            
        </style>
    </head>
    <body>
        
    <div class="Header">
        <div class="JudulHeader"><b>Daftar Santri SMK Tahfidz Al-Khair</b></div>

    </div>

    <div class="NavMenu">
        
        <ul>
            <li><a href="beranda.php">Home</a></li>
            <li><a href="tambah.php">Tambah Data</a></li>
            <li><a href="logout.php">Keluar</a></li>
        </ul>
        
        
    </div>
    <br></br>
        <br></br>

        
        
        <form action="" method="post">
            <input type="text" name="keyword" size="40" autofocus placeholder="Masukkan keyword pencarian..." autocomplete="off">
            <button type="submit" name="cari" style="background-color:#183A1D; color: white; padding: 5px 15px; ">Cari</button>
        </form>
        <br>

            

        
        <center>
        <table border="1" cellpadding="10" cellspacing="0">

        <tr>
            <th>No</th>
            <th>Nama Lengkap</th>
            <th>NIS</th>
            <th>Alamat</th>
            <th>Jurusan</th>
            <th>Poto</th>
            <th>Aksi</th>
        </tr>

        <?php $i = 1 + $dataAwal  ?>
        <?php  foreach( $santri as $row) : ?>

        <tr>
            <td style="text-align: center;"><?= $i ?></td>
            <td><?= $row["nama"]; ?></td>
            <td><?= $row["nis"]; ?></td>
            <td><?= $row["alamat"]; ?></td>
            <td><?= $row["jurusan"]; ?></td>
            <td style="text-align: center;"><img src="img/<?= $row["gambar"]; ?>" alt="" width="50" height="50"></td>
            <td style="text-align: center;">
             <a href="edit.php?id=<?= $row["id"]; ?> " >
                    <button class="button button2" style="background-color: #04AA6D; border: none; color: white; padding: 10px;">Edit</button>
             </a> 
                <a href="hapus.php?id=<?= $row["id"]; ?>" onclick="return confirm('Apakah anda yakin ingin penghapus data?');">
                    <button class="button button2" style="background-color: red; border: none; color: white; padding: 10px;">Hapus</button>
                </a>
            </td>

            
        </tr>

        <?php $i++; ?>
        <?php  endforeach; ?>

        </table>
        <br></br>

       <?php if ($halamanAktif > 1) : ?>
        <a href="?halaman=<?= $halamanAktif - 1; ?>" style="text-decoration: none;">&laquo;</a>
        <?php endif; ?>
        
        <?php for( $i = 1; $i <= $jumlahHalaman; $i++) : ?>
            <?php if( $i == $halamanAktif) : ?>

        <a href="?halaman=<?= $i; ?>" style="margin-top:100%; text-decoration: none; padding:10px; font-weight: bold; color: red;"><?= $i; ?></a>

        <?php else : ?>
            <a href="?halaman=<?= $i; ?>" style="text-decoration: none;"><?= $i; ?></a>
            <?php endif ?>
        <?php endfor; ?>

        <?php if ($halamanAktif < $jumlahHalaman) : ?>
        <a href="?halaman=<?= $halamanAktif + 1; ?>" style="text-decoration: none;">&raquo;</a>
        <?php endif; ?>
        </center>
        
    </body>
    
</html>