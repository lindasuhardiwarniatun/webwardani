<?php
session_start();
require 'functions.php';

if( isset($_COOKIE['id']) && isset($_COOKIE['key'])) {
    $id = $_COOKIE['id'];
    $key = $_COOKIE['key'];

    $result = mysqli_query($conn, "SELECT username FROM user WHERE id = $id");

    $row = mysqli_fetch_assoc($result);

    if( $key === hash('sha256', $row['username'])) {
        $_SESSION['login'] = true;
    }

}

if( isset($_SESSION["login"])) {
    header("location: index.php");
    exit;
}



if( isset($_POST["login"])) {

    $username = $_POST["username"];
    $password = $_POST["password"];

    $result = mysqli_query($conn, "SELECT * FROM user WHERE username = '$username'");


    if( mysqli_num_rows($result) === 1 ) {

        $row = mysqli_fetch_assoc($result);
        if( password_verify($password, $row["password"])) {

            $_SESSION["login"] = true;

            if( isset($_POST['remember'])) {


                setcookie('id', $row['id'], time() + 60);
                setcookie('key', hash('sha256', $row['username']),
                time() +60);
                 
            }

            header("location: index.php");
            exit;

        }
    }

    $error = true;

}

?>


<!DOCTYPE html>
<html>
    <head>
        <title>Login</title>
        <style>
            body {
            margin: 0;
            padding: 0;
            background: url(img/bgrdaftar.png);
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            background-attachment: fixed;
            font-family: sans-serif;
        }
            .input {
                position: fixed;
                top: 50%;
                left: 600px;
                transform: translate(-30%, -50%);
                background: rgba(21, 30, 24, 0.9);
                padding: 50px;
                width: 320px;
                box-shadow: 0px 0px 25px 10px black;
                border-radius: 15px;
            }
            .input h1 {
                text-align: center;
                color: white;
                font-size: 30px;
                font-family: sans-serif;
                letter-spacing: 3px;
                padding-top: 0;
                margin-top: -20px;
            }
            .box-input {
                display: flex;
                justify-content: space-between;
                margin: 10px;
                border-bottom: 2px solid white;
                padding: 8px 0;
            }
            
            .box-input input {
                width: 85%;
                padding: 5px 0;
                background: none;
                border: none;
                outline: none;
                color: white;
                font-size: 18px;
            }
            
            .box-input input::placeholder {
                color: white;
            }

            .btn-input .box-input input:hover {
                background: rgba(10, 10, 10, s 0.5);
            }

            .btn-input {
                margin-left: 10px;
                margin-bottom: 20px;
                background: none;
                border: 1px solid white;
                width: 92.5%;
                padding: 10px;
                color: white;
                font-size: 18px;
                letter-spacing: 3px;
                cursor: pointer;
                transition: all .2s;
                border-radius: 10px;
            }

            .btn-input:hover {
                background: black
            }

            .bottom {
                margin-left: 10px;
                margin-right: 10px;
                margin-bottom: -20px;
            }

            .NavMenu ul{
                list-style-type: none;
                margin-right: 80%;
                cursor: pointer;
                float: left;
                font-weight: 400;
                
            }
            .NavMenu ul li{
                list-style-type: none;
                display: inline-block;
                padding: 15px 15px;

            }
            .NavMenu ul li a{
                color: #FEFBE9;
                text-decoration: none;
            }

            .NavMenu ul li :hover{
                border-bottom: 3px solid #F0A04B;
                transition: all .3s ease ;
                
                
            }

        
        </style>
        <style>
            label{
                display: block;
            }
        </style>
    </head>
    <body>
    <div class="NavMenu">
        
        <ul>
            <li><a href="beranda.php">Home</a></li>
        </ul>
        
    </div>
    <div class="input">
        <h1>Halaman Login</h1>

        <?php if( isset($error)) : ?>
            <p style="color: red; font-style: italic;">username atau password salah</p>

            <?php endif; ?>

            <form action="" method="post">
            <div class="box-input">
                
                <input type="text" name="username" placeholder="Username">
            </div>

            <div class="box-input">
                
                <input type="password" name="password" placeholder="Password">
            </div>

                <p style="color:white;"><input type="checkbox" name="remember" placeholder="remember">Remember me</p>
              
            <button type="submit" name="login" class="btn-input">Login</button>
            
        
            </form>
            
        </table>
    </div>
    </body>
</html>