<?php
require 'functions.php';

if( isset($_POST["register"])) {
    if( registrasi($_POST) > 0 ) {
        echo "<script>
                alert('user berhasil ditambahkan');
                document.location.href = 'index.php';
        </script>";
    }else {
        echo mysqli_error($conn);
    }
}


?>

<!DOCTYPE html>
<html>
    <head>
        <title>Registrasi</title>
        <style>
            body {
            margin: 0;
            padding: 0;
            background: url(img/bgrdaftar.png);
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            background-attachment: fixed;
            font-family: sans-serif;
        }
        .input {
            position: fixed;
            top: 50%;
            left: 600px;
            transform: translate(-30%, -50%);
            background: rgba(21, 30, 24, 0.9);
            padding: 50px;
            width: 320px;
            box-shadow: 0px 0px 25px 10px black;
            border-radius: 15px;
        }
        .input h1 {
            text-align: center;
            color: white;
            font-size: 30px;
            font-family: sans-serif;
            letter-spacing: 3px;
            padding-top: 0;
            margin-top: -20px;
        }
        .box-input {
            display: flex;
            justify-content: space-between;
            margin: 10px;
            border-bottom: 2px solid white;
            padding: 8px 0;
        }
        
        .box-input input {
            width: 85%;
            padding: 5px 0;
            background: none;
            border: none;
            outline: none;
            color: white;
            font-size: 18px;
        }
        .box-input input::placeholder {
            color: white;
        }

        .btn-input .box-input input:hover {
            background: rgba(10, 10, 10, s 0.5);
        }

        .btn-input {
            margin-left: 10px;
            margin-bottom: 20px;
            background: none;
            border: 1px solid white;
            width: 92.5%;
            padding: 10px;
            color: white;
            font-size: 18px;
            letter-spacing: 3px;
            cursor: pointer;
            transition: all .2s;
            border-radius: 10px;
        }

        .btn-input:hover {
            background: black
        }

        .bottom {
            margin-left: 10px;
            margin-right: 10px;
            margin-bottom: -20px;
        }

        .bottom p {
            color: white;
            font-size: 15px;
            text-decoration: none;
            text-align: center;
        }

        .bottom a {
            color: lightgreen;
            font-size: 15px;
            text-decoration: none;
            
        }

        .bottom a:hover {
            text-decoration: underline;
        }
        .NavMenu ul{
                list-style-type: none;
                margin-right: 80%;
                cursor: pointer;
                float: left;
                font-weight: 400;
                
            }
            .NavMenu ul li{
                list-style-type: none;
                display: inline-block;
                padding: 15px 15px;

            }
            .NavMenu ul li a{
                color: #FEFBE9;
                text-decoration: none;
            }

            .NavMenu ul li :hover{
                border-bottom: 3px solid #F0A04B;
                transition: all .3s ease ;
                
                
            }

        </style>
    </head>
    <body>
    <div class="NavMenu">
        
        <ul>
            <li><a href="beranda.php">Home</a></li>
        </ul>
        
    </div>
    <div class="input">
        <h1>Halaman Registrasi</h1>
        

        <form action="" method="post">
            <div class="box-input">
                
                <input type="text" name="username" placeholder="Username">
            </div>

            <div class="box-input">
                
                <input type="password" name="password" placeholder="Password">
            </div>
            
            <div class="box-input">
                
                <input type="password2" name="password2" placeholder="Konfirmasi Password">
            </div>
            
            <button type="submit" name="register" class="btn-input">Register</button>

            <div class="bottom">
                <p>Sudah punya akun?
                    <a href="login.php">Login</a>
                </p>
            </div>
            
        
        </form>
        
    </div>
    </body>
</html>