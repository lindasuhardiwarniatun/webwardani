-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 23 Jul 2024 pada 04.05
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `uas4b`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `santri`
--

CREATE TABLE `santri` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `nis` varchar(10) NOT NULL,
  `alamat` varchar(200) NOT NULL,
  `jurusan` varchar(100) NOT NULL,
  `gambar` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `santri`
--

INSERT INTO `santri` (`id`, `nama`, `nis`, `alamat`, `jurusan`, `gambar`) VALUES
(1, 'Nazriyatussipa', '56842', 'Kalimantan', 'Tekhnik Komputer Jaringan', '669ed8c986bf9.jpeg'),
(2, 'Ajeung Putri Septiani', '12648', 'Lombok Tengah', 'Otomatisasi tata Kelola Perkantoran', '669ed8f3c538b.jpeg'),
(3, 'Ahmad Irfan', '64920', 'Lombok Barat', 'Tata Busana', '669ed91f47670.jpeg'),
(15, 'M_ Aprizal Sholihin', '16496', 'sambelia, Lombok Timur', 'Otomatisasi tata Kelola Perkantoran', '669ed941130ff.jpeg'),
(18, 'M_ Fajri Sobirin', '13965', 'Lombok Utara', 'Multimedia', '669ed980c2cc6.jpeg'),
(19, 'Muhammad Fauzan Ilmi', '10573', 'Jantuk Lombok Timur', 'Tekhnik Komputer Jaringan', '669ed9b483ca3.jpeg'),
(20, 'Muhammad Khoerurizal', '18453', 'Pringgasela, Lombok Timur', 'Perhotelan', '669ed9e3a8039.jpeg'),
(21, 'Alissha Nur Assyfa', '15279', 'Selong lombok timur', 'Otomatisasi tata Kelola Perkantoran', '669edd2158abb.jpeg');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `santri`
--
ALTER TABLE `santri`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `santri`
--
ALTER TABLE `santri`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
