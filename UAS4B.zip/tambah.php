<?php 
session_start();

if( !isset($_SESSION["login"])) {
    header("location: beranda.php");
}


require 'functions.php';


if( isset($_POST["submit"])) {

    if( tambah($_POST) > 0 ) {
        echo "
            <script>
            alert('Data berhasil ditambahkan');
            document.location.href = 'index.php';

            </script>

        ";
    }else {
        echo "
            <script>
            alert('Data gagal ditambahkan');
            document.location.href = 'index.php';

            </script>

        ";
    }

}

?>


<!DOCTYPE html>
<html>
    <head>
        <title>Tambah Data Santri</title>
        <style>
            body{
                background-color: #E1EEDD;
            }
            .Header{
                padding:20px;
                margin: 10px;
                
            }

            .JudulHeader{
                color: #F0A04B;
                font-family: Arial, Helvetica, sans-serif;
                position: absolute;
                margin-top: 100px;
                margin-left: 500px;
                font-size: 30px;
                
            }

            .NavMenu ul{
                list-style-type: none;
                margin-left: 70%;
                cursor: pointer;
                float: left;
                font-weight: 400;
                
            }

            .NavMenu ul li{
                list-style-type: none;
                display: inline-block;
                padding: 15px 15px;
            }
            .NavMenu ul li a{
                color: #183A1D;
                text-decoration: none;
            }

            .NavMenu ul li :hover{
                border-bottom: 3px solid #F0A04B;
                transition: all .3s ease ;
                
            }
            .input {
            position: fixed;
            top: 50%;
            left: 600px;
            transform: translate(-30%, -50%);
            background: rgba(41, 80, 34, 0.9);
            padding: 50px;
            width: 320px;
            box-shadow: 0px 0px 25px 10px #183A1D;
            border-radius: 15px;
            color:white;
        }
        </style>
    </head>
    <body>
    <div class="Header">
        <div class="JudulHeader"><b>Tambah Data Santri</b></div>

    </div>

    <div class="NavMenu">
        
        <ul>
            <li><a href="beranda.php">Home</a></li>
            
            <li><a href="logout.php">Keluar</a></li>
        </ul>
        
        
    </div>

    <div class="input">
        

        <table>
        <form action="" method="post" enctype="multipart/form-data">
            <tr>
                <td><label for="nama">Nama </label></td>
                <td><input type="text" name="nama" id="nama" required></td>
            </tr>
            <tr>
                <td><label for="nis">NIS </label></td>
                <td><input type="text" name="nis" id="nis" required></td>
            </tr>
            <tr>
                <td><label for="alamat">Alamat </label></td>
                <td><input type="text" name="alamat" id="alamat" required></td>
            </tr>
                <tr>
                    <td><label for="jurusan">Jurusan</label></td>
                    <td>
                    <select name="jurusan" id="jurusan" required>
                        <option value="Otomatisasi tata Kelola Perkantoran">Otomatisasi tata Kelola Perkantoran</option> 
                        <option value="Multimedia">Multimedia</option> 
                        <option value="Tekhnik Komputer Jaringan">Tekhnik Komputer Jaringan</option> 
                        <option value="Perhotelan">Perhotelan</option> 
                        <option value="Tata Boga">Tata Boga</option> 
                        <option value="Parwisata">Parwisata</option> 
                        <option value="Tata Busana">Tata Busana</option> 
                        <option value="Tehknik Mesin">Tehknik Mesin</option> 
                        <option value="Tehknik Instalasi Listrik">Tehknik Instalasi Listrik</option> 
                    </select>
                    </td>
                </tr>
                <tr>
                    <td><label for="gambar">Poto </label></td>
                    <td><input type="file" name="gambar" id="gambar" required></td>
                </tr>
                <tr>
                <td></td>
                    <td><button type="submit" name="submit">Tambah Data</button>
                        <button type="button" onclick="document.location.href='index.php'">Batal</button></td>
                    <td></td>
            </tr>
            

        </form>
        </table>
        </div>
    </body>
</html>